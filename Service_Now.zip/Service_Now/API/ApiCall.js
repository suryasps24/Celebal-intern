//POST

const createNewTicket = async (ticketDetails) =>
{
    var axios = require('axios');
    var data = JSON.stringify({
        "short_description":`${ticketDetails.short_description}`,
        "urgency":`${ticketDetails.urgency}`,
        "sys_created_on":`${ticketDetails.firstSeenOnDate}`,
        "impact":`${ticketDetails.impact}`,
        "description":`${ticketDetails.description}`,
        "business_service" : `${ticketDetails.services}`,
  
  });
  
  var config = {
    method: 'post',
    url: 'https://dev111879.service-now.com/api/now/table/incident?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=description',
    headers: { 
      'Authorization': 'Basic YWRtaW46QWY4SXhmcTVaR3pB', 
      'Content-Type': 'application/json', 
      'Cookie': 'BIGipServerpool_dev111879=629452554.37696.0000; JSESSIONID=F35E49A03C658A21F4762AFBE73D335A; glide_session_store=F900EF041B010110C0B8ED75604BCB2A; glide_user_route=glide.6be3735e98512560822b142642978889'
    },
    data : data
  };
  
  axios(config)
  .then(function (response) {
    console.log(JSON.stringify(response.data));
  })
  .catch(function (error) {
    console.log(error);
  });}

  //GET

  const getTicketStatus= async()=>{var axios = require('axios');

  var config = {
    method: 'get',
    url: 'https://dev111879.service-now.com/api/now/table/incident?sysparm_query=sys_created_onONOne%20year%20ago%40javascript%3Ags.beginningOfOneYearAgo()%40javascript%3Ags.endOfOneYearAgo()&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=description%2Cshort_description%2Cbusiness_service%2Cimpact%2Curgency%2Csys_created_on&sysparm_limit=5',
    headers: { 
      'Authorization': 'Basic YWRtaW46QWY4SXhmcTVaR3pB', 
      'Cookie': 'BIGipServerpool_dev111879=629452554.37696.0000; JSESSIONID=E711BB319682DA8301F051E310084BDB; glide_session_store=F35D78D21B700110C0B8ED75604BCB6E; glide_user_route=glide.6be3735e98512560822b142642978889'
    }
  };


    // let res = await axios(config)
    // console.log(res.data)
    // return await res.data

  
  return axios(config)
  .then(function (response) {
 //console.log (JSON.stringify(response.data));
 console.log(response.data);
   
 })
 .catch(function (error) {
   console.log(error);
 });


  }
  


  module.exports={
    createNewTicket : createNewTicket,
    getTicketStatus:getTicketStatus,

    
  }
