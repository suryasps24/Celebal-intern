module.exports = {
    raiseDialog:'raiseDialog',
    rootDialog:'rootDialog',
    getDialog:'getDialog',
    updateDialog:'updateDialog'
}