const {ActivityHandler,CardFactory,TurnContext}= require ('botbuilder');

class WelcomeHandler extends ActivityHandler{
    constructor(conversationState,rootDialog){
        super();

        if(!conversationState) throw new Error ("conversationState state required");
    
        this.conversationState=conversationState;
        this.rootDialog=rootDialog;
        this.accessor=this.conversationState.createProperty('DialogAccessor');
    
        
        //Message event 

         
      this.onMessage(async (context, next)=>{

        await this.rootDialog.run(context,this.accessor)
        await next();

        });
       

        this.onMembersAdded(async(context,next)=>{
             await context.sendActivity("Welcome to DMT SAP AMS Bot.I'm here to help you")
             await context.sendActivity({
                  attachments:[
                      CardFactory.heroCard(
                          'Select any below options to begin with:',
                           null,
                           
                          CardFactory.actions([
                            {
                                type:'imBack',
                                title:'Ask a Question',
                                value:'Ask a Question'
                                
                            },
                            {
                                  type:'imBack',
                                  title:'Raise Ticket',
                                  value:'Raise Ticket'
                                  
                              },
                              {
                                type:'imBack',
                                title:'Update Ticket',
                                value:'Update Ticket'
                            },
                            {
                                type:'imBack',
                                title:'Get Status',
                                value:'Get Status'
                            }
                          ])
                      )
                  ]
              })
              
        });
        
    }
}
module.exports.WelcomeHandler=WelcomeHandler