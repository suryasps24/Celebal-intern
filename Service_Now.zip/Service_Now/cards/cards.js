module.exports={
    RasieTicketCard:()=>{
        return {
            "type": "AdaptiveCard",
            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
            "version": "1.2",
            "body": [
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "New Request",
                    "size": "ExtraLarge",
                    "id": "Heading"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Please Describe your issue?"
                },
                {
                    "type": "Input.Text",
                    "maxLength": 0,
                    "isMultiline": true,
                    "placeholder": "Mention your problem here..",
                    "id": "description"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Feel free to add more description about your issue"
                },
                {
                    "type": "Input.Text",
                    "isMultiline": true,
                    "maxLength": 100,
                    "placeholder": "Type here(max. 100 words)",
                    "id": "shortdescription"
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "SAP Enterprise Services",
                            "value": "Enterprise"
                        },
                        {
                            "title": "SAP Financial Accounting",
                            "value": "Accounting"
                        },
                        {
                            "title": "SAP Controlling",
                            "value": "Controlling"
                        }
                    ],
                    "id": "Services",
                    "placeholder": "SAP Services*"
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "1.High",
                            "value": "high"
                        },
                        {
                            "title": "2.Medium",
                            "value": "medium"
                        },
                        {
                            "title": "3.Low",
                            "value": "low"
                        }
                    ],
                    "id": "impact",
                    "placeholder": "Impact*"
                },
                {
                    "type": "Input.ChoiceSet",
                    "choices": [
                        {
                            "title": "1.High",
                            "value": "high"
                        },
                        {
                            "title": "2.Medium",
                            "value": "medium"
                        },
                        {
                            "title": "3.Low",
                            "value": "low"
                        }
                    ],
                    "placeholder": "Urgency*",
                    "id": "urgency"
                },
                {
                    "type": "TextBlock",
                    "wrap": true,
                    "text": "Issue observed on:"
                },
                {
                    "type": "Input.Date",
                    "id": "date"
                }
            ],
            "actions": [
                {
                    "type": "Action.Submit",
                    "title": "Submit",
                    "id": "submit",
                    data: {

                        action: "Submit",

                        "msteams": {

                            "type": "messageBack",

                            "displayText": "Submit"

                        }

                    }
                },
                {
                    "type": "Action.Submit",
                    "title": "Cancel",
                    "id": "cancel",
                    data: {

                        action: "Cancel",

                        "msteams": {

                            "type": "messageBack",

                            "displayText": "Cancel"

                        }

                    }

                }
            ]
        }

        
    }
}