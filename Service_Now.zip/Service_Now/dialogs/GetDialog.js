var axios = require('axios');
const {ComponentDialog,WaterfallDialog}= require('botbuilder-dialogs');
const{CardFactory,ActivityHandler}=require('botbuilder');

const {getDialog}=require('../Constants/DialogIds');
const{getTicketStatus}=require('../API/ApiCall');



const GetDialogWF1 ='GetDialogWF1';

class GetDialog extends ComponentDialog{

    constructor(StateAccessor){
        super(getDialog,StateAccessor);

        //if(!conversationState) throw new Error ("conversationState state required");
        
       // this.conversationState=conversationState;
       
        this.StateAccessor=StateAccessor;

        this.addDialog(new WaterfallDialog(GetDialogWF1,[
            this.fetch.bind(this)
        ]));

        this.initialDialogId=GetDialogWF1;
    
    }
   
    async fetch(stepContext){
    
      await this.StateAccessor.get(stepContext.context);
      console.log(this.StateAccessor)
      await stepContext.context.sendActivity(getTicketStatus());
      await stepContext.context.sendActivity("Values in console ");

      return await stepContext.next()
    }

    
    
}

module.exports.GetDialog=GetDialog