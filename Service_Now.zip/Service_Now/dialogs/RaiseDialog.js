const {ComponentDialog,WaterfallDialog}= require('botbuilder-dialogs');
const{CardFactory,ActivityHandler}=require('botbuilder');

const {raiseDialog}=require('../Constants/DialogIds');
const{createNewTicket}=require('../API/ApiCall');
const{RasieTicketCard}=require('../cards/cards');

const RaiseDialogWF1 ='RaiseDialogWF1';

class RaiseDialog extends ComponentDialog{

    constructor(StateAccessor){
        super(raiseDialog,StateAccessor);
       
        this.StateAccessor=StateAccessor;

        this.addDialog(new WaterfallDialog(RaiseDialogWF1,[
            this.details.bind(this),
            this.abc.bind(this),
            this.finalStep.bind(this),

        ]));

        this.initialDialogId=RaiseDialogWF1;
    }
   
    async details(stepContext){
      await this.StateAccessor.get(stepContext.context);
     console.log(this.StateAccessor);
     
      await stepContext.context.sendActivity({
         attachments:[
             CardFactory.adaptiveCard(RasieTicketCard())
         ]
     })
    
     return ComponentDialog.EndOfTurn
    }
    async abc(stepContext){
        await this.StateAccessor.get(stepContext.context);
        console.log(this.StateAccessor);
        await stepContext.context.sendActivity("Heloo ABC")

        return ComponentDialog.EndOfTurn
    }
    
    async finalStep(stepContext){
        console.log(stepContext.context.activity);

        await this.StateAccessor.get(stepContext.context);
        console.log(this.StateAccessor);
        try {
          console.log('dfghjkl', stepContext.context.activity)
          console.log(stepContext.context.activity.value)
          if (stepContext.context.activity.value && stepContext.context.activity.value.action === 'Cancel')
          {
              console.log('cancelll')

            await stepContext.context.sendActivity('You have cancelled.')  
          }

          if (stepContext.context.activity.value && stepContext.context.activity.value.action === 'submit') {
            if(!stepContext.context.activity.value['shortdescription']){
              console.log('not herreereererr????')
              await stepContext.context.sendActivity('**Sorry, you cannot raise an empty ticket.**')
              
      
            }
            let res = stepContext.context.activity.value
                    
           
            let ticketDetails = {};
           ticketDetails.description = res.description;
           ticketDetails.shortdescription = res.shortdescription;
           ticketDetails.services = res.services
           ticketDetails.impact = res.impact
           ticketDetails.urgency = res.urgency
           ticketDetails.date = res.date

           console.log('--------//---',ticketDetails)
        
          let response = await createNewTicket(ticketDetails)
          console.log(response)
            
        }
        return ComponentDialog.EndOfTurn
    


        } 
        catch (err) {
            console.log(err)
          }
        }
        

        
      
        
    

  
}

module.exports.RaiseDialog=RaiseDialog