const {ComponentDialog,DialogSet,DialogTurnStatus,WaterfallDialog}=require('botbuilder-dialogs');
const  {rootDialog,raiseDialog,getDialog,updateDialog}=require('../Constants/DialogIds');
const{RaiseDialog,GetDialog,UpdateDialog}=require('./call');

const parseMessage ='parseMessage';

class RootDialog extends ComponentDialog{
    constructor(conversationState){
        super(rootDialog);
        if(!conversationState) throw new Error ("conversationState state required");

        this.conversationState=conversationState;
        this.StateAccessor =this.conversationState.createProperty('State accessor');
        this.addDialog(new WaterfallDialog(parseMessage,[
            this.routeMessage.bind(this)
        ]));

        this.addDialog(new RaiseDialog(this.StateAccessor));
        this.addDialog(new GetDialog(this.StateAccessor));
        this.addDialog(new UpdateDialog(this.StateAccessor));

        this.initialDialogId=parseMessage;
    }

    async run(context,accessor){
        try{
            const dialogSet = new DialogSet(accessor);
            dialogSet.add(this);
            const dialogContext =await dialogSet.createContext(context);
            const results =await dialogContext.continueDialog();
            if(results && results.status === DialogTurnStatus.empty){
                await dialogContext.beginDialog(this.id);
            }else{
                console.log('dialog stack is empty')
            }
        }catch(err){
            console.log(err);
        }
    }

    async routeMessage(stepContext){
        switch (stepContext.context.activity.text){
            case 'Raise Ticket':
               return await stepContext.beginDialog(raiseDialog);
            case 'update ticket':
                return await stepContext.beginDialog(updateDialog);
            case 'Get Status':
                return await stepContext.beginDialog(getDialog);
            default:
               await stepContext.context.sendActivity("Sorry Try again");   
                break;
            }
        return await stepContext.endDialog();
    }
}

module.exports.RootDialog=RootDialog;