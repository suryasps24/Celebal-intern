const {ComponentDialog,WaterfallDialog}= require('botbuilder-dialogs');
const{CardFactory,ActivityHandler}=require('botbuilder');

const {updateDialog}=require('../Constants/DialogIds');



const UpdateDialogWF1 ='UpdateDialogWF1';

class UpdateDialog extends ComponentDialog{

    constructor(StateAccessor){
        super(updateDialog,StateAccessor);

        //if(!conversationState) throw new Error ("conversationState state required");
        
       // this.conversationState=conversationState;
       
        this.StateAccessor=StateAccessor;

        this.addDialog(new WaterfallDialog(UpdateDialogWF1,[
            this.edit.bind(this)
        ]));

        this.initialDialogId=UpdateDialogWF1;
    }
   
    async edit(stepContext){
      await this.StateAccessor.get(stepContext.context);
      console.log(this.StateAccessor);
      await stepContext.context.sendActivity("UPDATE")

      return await stepContext.next()
    }
    
}
module.exports.UpdateDialog=UpdateDialog