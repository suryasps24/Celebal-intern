module.exports={
    RaiseDialog:require('./RaiseDialog').RaiseDialog,
    GetDialog:require('./GetDialog').GetDialog,
    UpdateDialog:require('./UpdateDialog').UpdateDialog
}