const restify = require('restify');
const axios = require('axios');


const {BotFrameworkAdapter,ConversationState,MemoryStorage} = require('botbuilder');
const { WelcomeHandler } = require('./Welcome');
const {RootDialog} = require('./dialogs/RootDialog');



const adapter = new BotFrameworkAdapter({
    appID:'',
    appPassword:''
});

adapter.onTurnError = async(context,error)=>{
    console.log('Error occured ')

    //send msg to user about error
    await context.sendActivity('Bot faced an error')
};

const server = restify.createServer();
server.use(restify.plugins.bodyParser());
server.listen(3978,()=>{
    console.log(`${server.name} Listening at ${server.url}`);
})

const memory = new MemoryStorage();
var conversationState = new ConversationState(memory);
const conversationReferences = {};


const rootDialog=new RootDialog(conversationState);
const mainBot =new WelcomeHandler(conversationState,rootDialog,conversationReferences)

server.post('/api/msg', async (req,res)=>{
   await adapter.process(req,res,async(context)=> mainBot.run(context))  
   
    });


